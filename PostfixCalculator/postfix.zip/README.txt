﻿a)
Projekti on valmis testattavaksi 
sellaisenaan postfix.vcxproj tiedoston kautta.

b)
Testitapaukset
---1 pisteen---
?
3
?
2
+
=

?
3
?
2
-
=

?
3
?
2
*
=

?
3
?
2
/
=
---2 pisteen---
?
1
?
2
x
-
=
--- 3 pisteen---
?
1
?
2
?
3
s
=
---4 pisteen---
?
2
?
3
a
=
---5 pisteen---
1 3 + 7.5 -

c)
Tavoittelen harjoitustyöllä viittä (5) pistettä.

d)
Palauttajan yhteystiedot:
esa.parkkila@eng.tamk.fi
+358445824867

e)
Tein harjoitustyön alusta loppuun 1 päivän aikana.
Sunnuntaina 26. lokakuuta 2014.
Aikaa tähän kului noin 6h 30min.

f)
Selitykset tasoittain
---1 pisteen---
Avasin teoriamonisteen ja kaivoin postfix laskin osion näkyville.
Monisteen tekstejä apuna hyödyntäen koodasin laskimelle luokan
ja tarvittavat metodit.

---2-4 pisteen---
Koodasin työn vaatimukset laskin luokan sisälle omiin metodeihinsa, yksi kerrallaan.
Hyödysin mahdollisimman tehokkaasti edellisiä metodeja seuraavien sisällä, vältellen koodin toistoa.

---5 pisteen---
Tämä oli työläin osuus, johon kului selvästi eniten aikaa.
Osittain siksi, että en ollut aikaisemmin käyttänyt mainin argc ja argv parametrejä.

Sain kuitenkin koodin ilta seitsemäksi valmiiksi ja testattua, ja oluen avattuani aloin kirjoittamaan README.txt tiedostoa.
Homma on nyt paketissa, joten kiitän ja kuittaan tähän.

