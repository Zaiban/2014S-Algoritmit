#ifndef UTILITY_H_
#define UTILITY_H_

#include <iostream>
bool user_says_yes();


#endif